package com.fredy.aplicationuns.Becas

data class Beca(
    val titulo: String,
    val descripcion: String,
    val imagenResId: Int
)